#!/bin/bash

function __kob_list {
curl -L "https://raw.githubusercontent.com/EtricKombat/KOBman/master/list" | less


}
